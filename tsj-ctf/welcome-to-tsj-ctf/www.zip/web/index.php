<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="We are glad to announce that TSJ CTF is going to be held on Feb. 26 02:00 ~ Feb. 28 05:00 (UTC).">
    <meta name="keywords" content="CTF,TSJ,TSJCTF">
    <meta name="author" content="TSJCTF">
    <meta property="og:title" content="TSJCTF">
    <meta property="og:description" content="We are glad to announce that TSJ CTF is going to be held on Feb. 26 02:00 ~ Feb. 28 05:00 (UTC).">
    <meta property="og:image" content="./assets/meta-image.jpg">
    <meta property="og:url" content="https://ctf.tsj.tw">
    <base href="https://ctf.tsj.tw/">
    <link rel="icon" type="image/x-icon" href="./assets/favicon.ico">
    <link rel="preload" href="assets/unifont-14.0.01.woff" as="font" crossorigin>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <script src="js/h4ck3r.js"></script>
    <title>TSJ CTF</title>
</head>

<body>
    <div class="banner home">
        <span>&gt;</span>
        <span class="cursor target">
            <!-- $type INITIALIZING-->
            <!-- $setTypeInterval 250 -->
            <!-- $type ...-->
            <!-- $setTypeInterval 10 -->
            <!-- $type <br>> -->

            <!-- $type SET Discord="<a href="https://discord.gg/u6taYEWGfr">https://discord.gg/u6taYEWGfr</a>"-->
            <!-- $type <br>> -->

            <!-- $type SET PAGE_LIST="[DETAIL, ABOUT_US]"-->
            <!-- $type <br>> -->

            <!-- $type USER LOGGING IN-->
            <!-- $setTypeInterval 250 -->
            <!-- $type ...-->
            <!-- $setTypeInterval 10 -->
            <!-- $type <br>> -->

            <!-- $type WELCOME!-->
        </span>
    </div>
    <div class="container">
        <div class="content">
            <div class="inner">
                <div class="title"><b>TSJ CTF</b></div>
                <div class="date">Sat, 26 Feb. 2022, 02:00 UTC<br> TO <br>Mon, 28 Feb. 2022, 05:00 UTC</div>
                <button onclick="location.href='https://chal.ctf.tsj.tw/';">Register</button>
            </div>
        </div>
    </div>
    <div class="list">
        <p><a href="./pages/detail.html">DETAIL</a></p>
        <p><a href="./pages/about_us.html">ABOUT_US</a></p>
    </div>
    <script src="https://code.jquery.com/jquery-1.11.3.js"></script>
    <script src="js/type.js"></script>
</body>

</html>
